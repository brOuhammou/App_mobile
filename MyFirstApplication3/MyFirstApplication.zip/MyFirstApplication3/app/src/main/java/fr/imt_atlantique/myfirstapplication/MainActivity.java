package fr.imt_atlantique.myfirstapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    private Button buttonvalidate;
    private Button buttonaddnumber;
    private Integer nb=0;
    DatePickerFragment datePickerFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        datePickerFragment = new DatePickerFragment( (TextView) findViewById(R.id.BirthDate));

        Button birthdateBtn = (Button) findViewById(R.id.btnEnterBirthdate);
        birthdateBtn.setOnClickListener((View v) -> {
            datePickerFragment.show(getSupportFragmentManager(), "datePicker");
        });






        buttonvalidate = (Button) findViewById(R.id.button);
        buttonaddnumber= (Button) findViewById(R.id.button2);
        Log.i("Lifecycle", "onCreate method");

        buttonvalidate.setOnClickListener(new View.OnClickListener () {
            public void onClick(View v) {
                Snackbar.make(v,"tpp", Snackbar.LENGTH_LONG).show();
            }
        });
        buttonaddnumber.setOnClickListener(new View.OnClickListener () {
            public void onClick(View v) {
                nb+=1;

                LinearLayout phoneaddnumberLayout =(LinearLayout) findViewById(R.id.Layout);
                LinearLayout phonenumberLayout = new LinearLayout(MainActivity.this);
                phonenumberLayout.setOrientation(LinearLayout.HORIZONTAL);
                phonenumberLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT));

                EditText phone= new EditText(MainActivity.this);
                phone.setHint("addnumber");

                Button buttondelete= new Button(MainActivity.this);
                buttondelete.setHint("delete");

                phonenumberLayout.addView(phone);
                phonenumberLayout.addView(buttondelete);
                phoneaddnumberLayout.addView(phonenumberLayout);

                buttondelete.setOnClickListener(new View.OnClickListener () {
                    public void onClick(View v) {
                        nb-=1;
                        //Integer nb1=Math.max(nb,0);
                        //String strnb= nb1.toString();
                        //Snackbar.make(v,strnb, Snackbar.LENGTH_LONG).show();
                        phonenumberLayout.removeAllViews();

                    }
                });

            }

        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    public void resetAction (MenuItem item){
        Snackbar.make(findViewById(R.id.myConstraintLayout),"pp", Snackbar.LENGTH_LONG).show();
    }


}